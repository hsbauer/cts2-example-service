package mayo.edu.cts2.client.rest.scala

import javax.net.ssl._
import java.net.URL
import io.Source
import sun.misc.BASE64Encoder
import java.security.cert.X509Certificate
;

/**
 * Created with IntelliJ IDEA.
 * Author: Scott Bauer bauer.scott@mayo.edu
 * Date: 10/3/12
 * Time: 7:50 AM
 */
object CTS2RestClientAuthentication extends App{
  val connection =
    new URL("https://informatics.mayo.edu/cts2/services/mat/valueset/2.16.840.1.113883.3.526.02.99/resolution").openConnection().asInstanceOf[HttpsURLConnection]
  val encoder = new BASE64Encoder()
  val credentials: String = encoder.encode(("hsbauer" + ":" + "Norm10$$").getBytes)
  connection.setRequestProperty("Authorization", "Basic "+credentials)
  val hv = new HostnameVerifier() {
    def verify(urlHostName: String, session: SSLSession) = true
  }
  connection.setHostnameVerifier(hv)
  val trustAllCerts = Array[TrustManager](new X509TrustManager() {
    def getAcceptedIssuers: Array[X509Certificate] = null
    def checkClientTrusted(certs: Array[X509Certificate], authType: String){}
    def checkServerTrusted(certs: Array[X509Certificate], authType: String){}
  })

  val sc = SSLContext.getInstance("SSL")
  sc.init(null, trustAllCerts, new java.security.SecureRandom())
  connection.setSSLSocketFactory(sc.getSocketFactory())
  val inputStream = connection.getInputStream
  val src = Source.fromInputStream(inputStream)
  src.getLines().foreach(println)
}
