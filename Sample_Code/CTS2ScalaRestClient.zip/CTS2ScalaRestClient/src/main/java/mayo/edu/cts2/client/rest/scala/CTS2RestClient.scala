package mayo.edu.cts2.client.rest.scala

import java.net.{HttpURLConnection, URL}
import io.Source

/**
 * Created with IntelliJ IDEA.
 * Author: Scott Bauer bauer.scott@mayo.edu
 * Date: 10/2/12
 * Time: 3:17 PM
 */
object CTS2RestClient extends App{
  val connection =
    new URL("http://informatics.mayo.edu/cts2/rest/valuesets").openConnection().asInstanceOf[HttpURLConnection]
  val inputStream = connection.getInputStream
  val src = Source.fromInputStream(inputStream)
  src.getLines().foreach(println)
}
