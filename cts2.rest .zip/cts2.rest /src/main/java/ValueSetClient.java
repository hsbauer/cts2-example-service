
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import edu.mayo.cts2.framework.core.json.JsonConverter;
import edu.mayo.cts2.framework.model.valueset.ValueSetCatalogEntryDirectory;
import edu.mayo.cts2.framework.model.valueset.ValueSetCatalogEntrySummary;


public class ValueSetClient {
	
	public void getValueSets(){
		
	String uri = "http://informatics.mayo.edu/cts2/rest/valuesets";
	
	URL url; 
	try { url = new URL(uri);
	HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	if (connection.getResponseCode() != 200) 
	{ throw new RuntimeException("Failed�: The HTTP error code is�: " + connection.getResponseCode()); }

	BufferedReader br = new BufferedReader(new InputStreamReader( (connection.getInputStream())));
	String output; 
	System.out.println("Output from Server .... \n"); 
	while ((output = br.readLine())!= null) { System.out.println(output); }

	}catch(Exception e){
		
	}
	}
	
	public void getValueSet() {
		String uri = "http://informatics.mayo.edu/cts2/rest/valuesets?matchvalue=Sequence&format=json";
		URL url;
		try {
			url = new URL(uri);

			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setRequestProperty("Accept", "text/json");

			if (connection.getResponseCode() != 200) {
				throw new RuntimeException("Failed�: The HTTP error code is�: "
						+ connection.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(connection.getInputStream())));
			String output;
			StringBuilder builder = new StringBuilder();

			while ((output = br.readLine()) != null) {
				builder.append(output);
			}
			JsonConverter converter = new JsonConverter();
			ValueSetCatalogEntryDirectory valuesetcat = converter.fromJson(
					builder.toString(), ValueSetCatalogEntryDirectory.class);

			List<ValueSetCatalogEntrySummary> sum = valuesetcat
					.getEntryAsReference();
			for (ValueSetCatalogEntrySummary s : sum) {
				System.out.println(s.getFormalName());
				System.out.println(s.getCurrentDefinition());
				System.out.println(s.getResourceName());
				System.out.println(s.getValueSetName());
				System.out.println(s.getHref());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



public static void main(String[] args){
	new ValueSetClient().getValueSet();
}
}
