__author__ = 'sbauer'
from restful_lib import Connection

conn = Connection("http://informatics.mayo.edu/cts2/rest")
reply = conn.request_get("/valuesets")
if reply['headers']['status'] == '200':
    print reply['body']


conn = Connection("http://informatics.mayo.edu/cts2/rest")
reply = conn.request_get("/valuesets?format=json",headers={'Accept':'application/json;q=1.0'})
if reply['headers']['status'] == '200':
    print reply['body']
    print eval(reply['body'])

conn = Connection("http://informatics.mayo.edu/cts2/rest")
print conn.request_get("/valuesets?matchvalue='Sequence'")['body']


