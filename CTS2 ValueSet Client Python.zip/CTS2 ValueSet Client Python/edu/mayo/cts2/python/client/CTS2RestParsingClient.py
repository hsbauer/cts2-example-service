__author__ = 'sbauer'

import urllib2
from xml.dom.minidom import parseString

file = urllib2.urlopen('http://informatics.mayo.edu/cts2/rest/valuesets')
data = file.read()
file.close()
dom = parseString(data)

print "Listing Value Sets from this resource: "
entries = dom.getElementsByTagName('entry')
for node in entries:
    print node.getAttribute('resourceName')

print "Resolving a single large value set:"
firstVs = dom.getElementsByTagName("entry")[0]
valueSet = firstVs.getAttribute("href")
valueSet += "/resolution"
file1 = urllib2.urlopen(valueSet)
data1 = file1.read()
file1.close()
dom1 = parseString(data1)
entries = dom1.getElementsByTagName('entry')
for node in entries:
        print "\nValue Set Entry: "
        vsentryName = node.getElementsByTagName('core:name')[0]
        name = vsentryName.firstChild
        text = name.nodeValue
        vsentryNSpace = node.getElementsByTagName('core:namespace')[0]
        namespace = vsentryNSpace.firstChild
        nstext = namespace.nodeValue
        vsentryDesignation = node.getElementsByTagName('core:designation')[0]
        designation = vsentryDesignation.firstChild
        desigtext = designation.nodeValue
        print text
        print nstext
        print desigtext